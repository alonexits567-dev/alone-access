ALONE ACCESS — Purple & Black

This project contains a static website plus Vercel serverless API routes for Supabase access-key verification and admin generation/revocation.

IMPORTANT:
- The current live website is not changed by downloading this package.
- The backend will not work until the package is deployed to Vercel and the environment variables are configured.
- In Vercel Project Settings > Environment Variables, set these for Production:
  SUPABASE_URL = https://fiuqcyzqptqkoyvgmlhb.supabase.co
  SUPABASE_SERVICE_ROLE_KEY = your Supabase service_role secret (never put it in HTML or share it in chat)
  ALONE_ADMIN_SECRET = a long, unique secret you create and keep private
- Redeploy after adding or changing environment variables.
- Keep service-role/admin secrets private. Never add them to index.html.
- The SQL functions must exist and be executable by service_role. The frontend only verifies keys; key generation/revocation endpoints require the x-admin-secret header.
- Do not share the admin secret with site visitors. The API endpoints are not a complete admin dashboard.
